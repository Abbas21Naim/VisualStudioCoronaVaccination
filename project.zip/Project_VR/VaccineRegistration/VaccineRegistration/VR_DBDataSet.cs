﻿namespace VaccineRegistration
{


    partial class VR_DBDataSet
    {
    }
}

