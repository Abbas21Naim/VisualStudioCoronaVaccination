﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VaccineRegistration
{
    public partial class Appointments : Form
    {
        public Appointments()
        {
            InitializeComponent();
        }

        private mainForm mform = null;
        public Appointments(mainForm mform)
        {
            this.mform = mform;
            InitializeComponent();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = myConnection.GetConnection();

            try
            {

                string sqlQuery = " SELECT p.name,p.age, p.phoneno ,  v.vaccine_type ,p.duedate FROM dbo.tbl_patient p ,dbo.tbl_vaccine v where p.accepted='yes' and p.vaccine_id=v.id " +
                    " and p.thedate >= @val1 and  p.thedate<= @val2 ";
                SqlCommand cmd = new SqlCommand(sqlQuery, conn);
                cmd.Parameters.AddWithValue("@val1", dtpFrom.Value);
                cmd.Parameters.AddWithValue("@val2", dtpTo.Value);
                SqlDataAdapter sdr = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                dtg_resultRq.DataSource = dt;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                myConnection.Dispose(conn);
            }
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            if (mform != null)
            {
                mform.Show();
                this.Close();
            }
            else
            {
                mform = new mainForm();
                mform.Show();
                Close();
            }
        }
    }
}
