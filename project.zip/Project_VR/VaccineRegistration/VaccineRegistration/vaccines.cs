﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VaccineRegistration
{
    public partial class vaccines : Form
    {

        private mainForm mf=null;
        public vaccines()
        {
            InitializeComponent();
        }

        public vaccines(mainForm mf)
        {
            this.mf = mf;
            InitializeComponent();
        }

        private void Vaccines_Load(object sender, EventArgs e)
        {

            // this.tbl_vaccineTableAdapter.Fill(this.vaccinesDataSet.tbl_vaccine);

            fillDatagrid();
        }

        public void fillDatagrid()
        {
            SqlConnection conn = myConnection.GetConnection();
            DataSet ds = new DataSet();
            try
            {

                string query = "select id,vaccine_type from tbl_vaccine";
                SqlDataAdapter ad = new SqlDataAdapter(query, conn);
                ad.Fill(ds, "Test1");
                dtg_vaccines.DataSource = ds.Tables["Test1"];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                myConnection.Dispose(conn);
            }
        }

        private void BtnAddVaccine_Click(object sender, EventArgs e)
        {
            if(txtVaccineName==null  || txtVaccineName.Text.Equals(""))
            {
                MessageBox.Show("please a vaccine name");
                return;
            }


            SqlConnection con = myConnection.GetConnection();
            try
            {
                
                String query = "INSERT INTO tbl_vaccine VALUES (@val1)";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@val1", txtVaccineName.Text.ToString().Trim());
                command.ExecuteNonQuery();
                con.Close();
                dtg_vaccines.Update();
                dtg_vaccines.Refresh();
                fillDatagrid();
                MessageBox.Show("vaccine is added");
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            finally
            {
                myConnection.Dispose(con);
            }
            

        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            Int32 selectedRowCount = dtg_vaccines.Rows.GetRowCount(DataGridViewElementStates.Selected);

            if (selectedRowCount == 0)
            {
                MessageBox.Show("no rows are selected");
                return;
            }

            SqlConnection conn = myConnection.GetConnection();
            string cellValue = "";
            try
            {
                string query = "delete from tbl_vaccine where id=@val1";
                SqlCommand cmd = null;

                foreach (var row in dtg_vaccines.SelectedRows)
                {
                    cellValue =Convert.ToString( ((DataGridViewRow)row).Cells[0].Value);
                    cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@val1", cellValue);
                    cmd.ExecuteNonQuery();
                    dtg_vaccines.Refresh();
                    dtg_vaccines.Update();
                    
                }
                fillDatagrid();
                MessageBox.Show("rows are deleted..");
                 
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            finally
            {
                myConnection.Dispose(conn);
            }
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            if (mf == null)
            {
              mf = new mainForm();
              mf.Show();
            }
            else {
                mf.Show();
            }
            
            this.Close();
        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {

            if (txtVaccineName == null || txtVaccineName.Text.Equals(""))
            {
                MessageBox.Show("please a vaccine name");
                return;
            }


            SqlConnection con = myConnection.GetConnection();
            try
            {

                String query = "INSERT INTO tbl_vaccine VALUES (@val1)";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@val1", txtVaccineName.Text.ToString().Trim());
                command.ExecuteNonQuery();
                con.Close();
                dtg_vaccines.Update();
                dtg_vaccines.Refresh();
                fillDatagrid();
                MessageBox.Show("vaccine is added");

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            finally
            {
                myConnection.Dispose(con);
            }


        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {

            Int32 selectedRowCount = dtg_vaccines.Rows.GetRowCount(DataGridViewElementStates.Selected);

            if (selectedRowCount == 0)
            {
                MessageBox.Show("no rows are selected");
                return;
            }

            SqlConnection conn = myConnection.GetConnection();
            string cellValue = "";
            try
            {
                string query = "delete from tbl_vaccine where id=@val1";
                SqlCommand cmd = null;

                foreach (var row in dtg_vaccines.SelectedRows)
                {
                    cellValue = Convert.ToString(((DataGridViewRow)row).Cells[0].Value);
                    cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@val1", cellValue);
                    cmd.ExecuteNonQuery();
                    dtg_vaccines.Refresh();
                    dtg_vaccines.Update();

                }
                fillDatagrid();
                MessageBox.Show("rows are deleted..");

            }
            catch (Exception ex)
            {
                MessageBox.Show("can't delete maybe you have Related Patient with this Vaccine");
                Console.WriteLine(ex.Message);

            }
            finally
            {
                myConnection.Dispose(conn);
            }
        }
    }
}
