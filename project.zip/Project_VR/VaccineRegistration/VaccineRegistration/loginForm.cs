﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VaccineRegistration
{
    public partial class loginForm : Form
    {
        public loginForm()
        {
            InitializeComponent();
        }
       
        private string formName = null;
        private mainForm mform = null;
        public loginForm(string formName,mainForm mform)
        {
            this.formName = formName;
            this.mform = mform;
            InitializeComponent();

        }
        private void Button1_Click(object sender, EventArgs e)
        {
          
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = myConnection.GetConnection();
            string query = " select l.username,l.password from tbl_login l";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = null;

            try
            {
                if (txt_username.Text.Equals("") || txt_psswd.Text.Equals(""))
                {
                    MessageBox.Show("enter username and password");
                    return;
                }
                reader = cmd.ExecuteReader();
                string username = "";
                string passwd = "";

                while (reader.Read())
                {
                    username = reader[0].ToString().Trim();
                    passwd = reader[1].ToString().Trim();

                    if (username.Equals(txt_username.Text.ToString().Trim()) && passwd.Equals(txt_psswd.Text.ToString().Trim()))
                    {
                        this.mform.setLoggenIn(true);

                        if (this.formName != null && this.formName.Equals("requests"))
                        {
                            requests r = new requests(mform);
                            r.Show();
                            this.Close();
                        }
                        else if (this.formName != null && this.formName.Equals("appointments"))
                        {
                            Appointments app = new Appointments(mform);
                            app.Show();
                            this.Close();
                        }
                        else
                        {
                            vaccines v = new vaccines(mform);
                            v.Show();
                            this.Close();
                        }

                        return;
                    }



                }
                this.mform.setLoggenIn(false);
                MessageBox.Show("invalid username or password");


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                myConnection.Dispose(conn);
            }

        }
    }
}
