
 
create database VR_DB

CREATE TABLE [dbo].[tbl_login](
	[id] [int] primary key IDENTITY(1,1) NOT NULL,
	[username] [varchar](50) NOT NULL,
	[password] [varchar](50) NOT NULL
)
CREATE TABLE [dbo].[tbl_vaccine](
	id int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	vaccine_type varchar(50) NOT NULL 
);

CREATE TABLE [dbo].[tbl_patient](
	id int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	vaccine_id [int] NULL  FOREIGN KEY REFERENCES tbl_vaccine(id),
	name varchar(50) NOT NULL,
	phoneno varchar(50) NULL,
	age int NOT NULL,
	gender varchar NOT NULL,
	location varchar(50) NULL,
	accepted varchar(50) NULL,
	thedate DATE,
	duedate DATE
);



insert into tbl_login values('adonis','123')
insert into tbl_login values('ali','123')

insert into tbl_vaccine values('Pfizer')
insert into tbl_vaccine values('Astrazenica')
insert into tbl_vaccine values('moderna')

insert into tbl_patient(vaccine_id,name,phoneno,age,gender,location,accepted,thedate,duedate) values(1,'samir','00360',18,'m','beirut','yes','05-12-2021','05-12-2022')
insert into tbl_patient(vaccine_id,name,phoneno,age,gender,location,accepted,thedate,duedate) values(1,'mirna','003360',18,'f','tyre','no','06-12-2021','06-12-2022')
insert into tbl_patient(vaccine_id,name,phoneno,age,gender,location,accepted,thedate,duedate) values(1,'Ahmad','003360',18,'m','beirut','yes','08-12-2021','08-12-2022')
insert into tbl_patient(vaccine_id,name,phoneno,age,gender,location,accepted,thedate,duedate) values(1,'jana','003360',18,'f','tyre','no','07-12-2021','07-12-2022')


select l.username,l.password from tbl_login l

select * from tbl_login

select * from tbl_patient

select * from tbl_vaccine

SELECT p.id, p.name,p.age, p.phoneno ,  v.vaccine_type ,thedate FROM dbo.tbl_patient p ,dbo.tbl_vaccine v where p.vaccine_id=v.id  
SELECT p.name,p.age, p.phoneno ,  v.vaccine_type ,p.duedate FROM dbo.tbl_patient p ,dbo.tbl_vaccine v where p.accepted='yes' and p.vaccine_id=v.id

 
  
  

  
  